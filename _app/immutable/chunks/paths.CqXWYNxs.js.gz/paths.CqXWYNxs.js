var s;const a=((s=globalThis.__sveltekit_16iq2wk)==null?void 0:s.base)??"/unwired-web";var e;const t=((e=globalThis.__sveltekit_16iq2wk)==null?void 0:e.assets)??a;export{t as a,a as b};
