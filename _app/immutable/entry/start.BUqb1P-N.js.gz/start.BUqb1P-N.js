import{a as t}from"../chunks/entry.DAft6Iyg.js";export{t as start};
