import{a as t}from"../chunks/entry.FhdK03gH.js";export{t as start};
