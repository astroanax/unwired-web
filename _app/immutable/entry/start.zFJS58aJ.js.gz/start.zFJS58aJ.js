import{a as t}from"../chunks/entry.CwxEd6iD.js";export{t as start};
