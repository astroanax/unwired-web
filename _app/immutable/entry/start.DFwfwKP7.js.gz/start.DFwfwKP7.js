import{a as t}from"../chunks/entry.CvkE436L.js";export{t as start};
