import{a as t}from"../chunks/entry.BQjNnx3P.js";export{t as start};
