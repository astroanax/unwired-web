import{a as t}from"../chunks/entry.18I5ZzZS.js";export{t as start};
