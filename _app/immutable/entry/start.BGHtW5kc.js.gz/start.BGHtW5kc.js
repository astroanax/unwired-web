import{a as t}from"../chunks/entry.CTpC7hjg.js";export{t as start};
