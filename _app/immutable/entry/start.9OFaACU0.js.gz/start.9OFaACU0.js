import{a as t}from"../chunks/entry.By5LDFER.js";export{t as start};
