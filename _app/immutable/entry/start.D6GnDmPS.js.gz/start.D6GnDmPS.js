import{a as t}from"../chunks/entry.BZWbDKta.js";export{t as start};
